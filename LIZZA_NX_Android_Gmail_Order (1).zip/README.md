# LIZZA NX Android App

This is a lightweight Android WebView app wrapper for:

https://lizzanx.lizza.workers.dev/

## Build

Open this folder in Android Studio and let Gradle sync.

Then:
- Build > Build APK(s)
- For a release APK, configure a signing key and use Generate Signed App Bundle / APK.

## Notes

- The app loads the existing LIZZA NX website, so changes made to the website are reflected in the app.
- JavaScript, local storage and cookies are enabled for normal storefront functionality.
- WhatsApp, phone and email links are handed to Android when the website opens them.
- App ID: com.lizza.nx
- Version: 1.0
