package com.lizza.nx

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val homeUrl = "https://lizzanx.lizza.workers.dev/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            builtInZoomControls = false
            displayZoomControls = false
            userAgentString = "$userAgentString LIZZA-NX-Android"
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webChromeClient = WebChromeClient()

        webView.addJavascriptInterface(OrderBridge(), "LizzaOrder")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                injectOrderButton()
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                return handleUrl(request.url.toString())
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl(homeUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    private fun injectOrderButton() {
        val js = """
            (function(){
              if(window.__lizzaGmailInstalled) return;
              window.__lizzaGmailInstalled=true;
              function install(){
                if(document.getElementById('lizza-gmail-order')) return;
                var bag=[...document.querySelectorAll('*')].find(e=>e.children.length===0 && (e.textContent||'').trim()==='Your Bag');
                if(!bag) return;
                var box=bag.parentElement;
                for(var i=0;i<5 && box;i++,box=box.parentElement){
                  if((box.innerText||'').includes('WhatsApp Enquiry')) break;
                }
                var btn=document.createElement('button');
                btn.id='lizza-gmail-order';
                btn.textContent='ORDER VIA GMAIL';
                btn.style.cssText='display:block;width:100%;margin:12px 0;padding:14px;border:0;border-radius:8px;background:#111;color:#fff;font-weight:700;letter-spacing:.5px;cursor:pointer;';
                btn.onclick=function(){
                  var details=(box&&box.innerText)||'Your Bag is empty.';
                  var name=prompt('Customer name:',''); if(name===null)return;
                  var phone=prompt('Phone number:',''); if(phone===null)return;
                  var address=prompt('Delivery address:',''); if(address===null)return;
                  window.LizzaOrder.sendOrder(name,phone,address,details);
                };
                (box||bag.parentElement).appendChild(btn);
              }
              install();
              new MutationObserver(install).observe(document.body,{childList:true,subtree:true});
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    inner class OrderBridge {
        @android.webkit.JavascriptInterface
        fun sendOrder(name: String, phone: String, address: String, cart: String) {
            val subject = "LIZZA NX Order - $name"
            val body = """
                LIZZA NX ORDER

                Customer Name: $name
                Phone: $phone
                Delivery Address: $address

                ORDER / BAG DETAILS:
                $cart

                Please confirm price, size, availability and delivery details.
            """.trimIndent()
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                putExtra(Intent.EXTRA_EMAIL, arrayOf("lizzaanand@gmail.com"))
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
            }
            try { startActivity(intent) } catch (_: Exception) {
                val fallback = Intent(Intent.ACTION_SEND).apply {
                    type = "message/rfc822"
                    putExtra(Intent.EXTRA_EMAIL, arrayOf("lizzaanand@gmail.com"))
                    putExtra(Intent.EXTRA_SUBJECT, subject)
                    putExtra(Intent.EXTRA_TEXT, body)
                }
                startActivity(Intent.createChooser(fallback, "Send order with email"))
            }
        }
    }

    private fun handleUrl(url: String): Boolean {
        val lower = url.lowercase()

        if (lower.startsWith("http://") || lower.startsWith("https://")) {
            // Keep the LIZZA website inside the app.
            // External services such as WhatsApp are handed to their Android apps.
            if (lower.startsWith("https://lizzanx.lizza.workers.dev")) {
                return false
            }

            if (lower.startsWith("https://wa.me") ||
                lower.startsWith("https://api.whatsapp.com") ||
                lower.startsWith("whatsapp://") ||
                lower.startsWith("tel:") ||
                lower.startsWith("mailto:")) {
                return openExternal(url)
            }

            return false
        }

        return openExternal(url)
    }

    private fun openExternal(url: String): Boolean {
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            true
        } catch (_: ActivityNotFoundException) {
            false
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
